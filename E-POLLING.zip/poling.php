<?php session_start();
if(isset($_SESSION['id'])){
	$userid=$_SESSION['id'];
	include("conn.php");
	$pemilih = mysql_fetch_array(mysql_query("select*from tb_user WHERE nik='$userid'"));
	
	
	echo"
	<!DOCTYPE html>
	<html lang='en'>
	<head>
	<meta charset='utf-8'>
	<title>Admin E-Polling</title>
	<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>
	<meta name='apple-mobile-web-app-capable' content='yes'>
	<link href='css/bootstrap.min.css' rel='stylesheet'>
	<link href='css/bootstrap-responsive.min.css' rel='stylesheet'>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'
        rel='stylesheet'>
	<link href='css/font-awesome.css' rel='stylesheet'>
	<link href='css/style.css' rel='stylesheet'>
	<link href='css/pages/dashboard.css' rel='stylesheet'>
	<link href='css/pages/reports.css' rel='stylesheet'>
	
	</head>
<body>
<div class='navbar navbar-fixed-top'>
	<div class='navbar-inner'>
		<div class='container'>
			<a class='brand' href='#'> E-Polling </a>
			<ul class='nav pull-right'>
				<li class='dropdown'><a href='#'' class='dropdown-toggle' data-toggle='dropdown'></a> <a href='logout.php' class='brand'><i class='shortcut-icon icon-off'></i><span> Logout</span></a></li>
			</ul>
		</div>
	</div>
</div>
<div class='main'>
	<div id='loader-wrapper'>	
		<div id='loader'></div>
	</div>
	<div class='main-inner'>
		<div class='container'>
			<div class='row'>	
				<h2 align='center'>Selamat datang $pemilih[nama] di HALAMAN E-Polling</h2> </br>
				
				<div class='span12'>
					<div class='widget'>
						<div class='widget-header'> <i class='icon-bookmark'></i>
							<h3>Pilih Pilihan Anda</h3>
						</div>
						<div class='widget-content'>
							<div class='shortcuts'>";
							$calonQ=mysql_query("select*from pilihan");
							$no=0;
							while($calon=mysql_fetch_array($calonQ)){
								$ketua=mysql_fetch_array(mysql_query("select*from tb_user where nik='$calon[ketua]'"));
								$wakil=mysql_fetch_array(mysql_query("select*from tb_user where nik='$calon[wakil]'"));
								$no++;
							echo"
								<a href='proses.php?&nik_user=$userid&idpil=$calon[id]' class='shortcut'><h3> 0$no </h3></br><img src='$calon[fketua]' width='200px' /><span class='shortcut-label'></br> $ketua[nama] || $wakil[nama]</span> </a>";
							}
							echo"
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<script src='js/jquery-1.7.2.min.js'></script> 
<script src='js/excanvas.min.js'></script> 
<script src='js/chart.min.js' type='text/javascript'></script> 
<script src='js/bootstrap.js'></script>
<script language='javascript' type='text/javascript' src='js/full-calendar/fullcalendar.min.js'></script>
 
<script src='../js/base.js'></script> 	
</body>
</html>	";
}else{
	echo"<script>alert('Anda belum login! Silahkan login terlebih dahulu!');window.location='index.php';</script>"; 
}

include("js/dis.php");
?>