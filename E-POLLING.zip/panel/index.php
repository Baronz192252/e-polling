<?php session_start();
include("../js/dis.php");
if(isset($_SESSION['id'])){
	$userid=$_SESSION['id'];
	include("../conn.php");
	require("../excel_reader.php");
	$admin = mysql_fetch_array(mysql_query("select*from tb_admin WHERE nik_user='$userid'"));
	if($admin!=0){
		$nama=mysql_fetch_array(mysql_query("select*from tb_user WHERE nik='$userid'"));
		$me = $nama['nama'];
	}else{
		$nama=mysql_fetch_array(mysql_query("select*from xsu WHERE id='$userid'"));
		$me = $nama['username'];
	}
	(isset($_GET['pg'])) ? $pg = $_GET['pg'] : $pg = '';
	(isset($_GET['ac'])) ? $ac = $_GET['ac'] : $ac = '';
echo"
	<!DOCTYPE html>
	<html lang='en'>
	<head>
	<meta charset='utf-8'>
	<title>Admin Polling</title>
	<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>
	<meta name='apple-mobile-web-app-capable' content='yes'>
	<link href='../css/bootstrap.min.css' rel='stylesheet'>
	<link href='../css/bootstrap-responsive.min.css' rel='stylesheet'>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'
        rel='stylesheet'>
	<link href='../css/font-awesome.css' rel='stylesheet'>
	<link href='../css/style.css' rel='stylesheet'>
	<link href='../css/pages/dashboard.css' rel='stylesheet'>
	<link href='../css/pages/reports.css' rel='stylesheet'>


<!-- Bootstrap AdminLTE -->
	<link rel='stylesheet' href='../plugins/font-awesome-4.4.0/css/font-awesome.min.css'/>
<!--	<link rel='stylesheet' href='../bower_components/bootstrap/dist/css/bootstrap.min.css'> -->
	<link rel='stylesheet' href='../dist/css/AdminLTE.min.css'/>
	<link rel='stylesheet' href='../dist/css/preloader.css'/>
	<link rel='stylesheet' href='../dist/css/skins/skin-green.min.css'/>
	<link rel='stylesheet' href='../dist/css/skins/skin-green-light.min.css'/>
	<link rel='stylesheet' href='../plugins/datatables/dataTables.bootstrap.css'/>
	<link rel='stylesheet' href='../bower_components/font-awesome/css/font-awesome.min.css'>
	<link rel='stylesheet' href='../bower_components/Ionicons/css/ionicons.min.css'>
	<link rel='stylesheet' href='../dist/css/skins/_all-skins.css'>
	<link rel='stylesheet' href='../dist/css/skins/_all-skins.min.css'>
	<link rel='stylesheet' href='../bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css'>
	<link rel='stylesheet' href='../bower_components/bootstrap-daterangepicker/daterangepicker.css'>
	<link rel='stylesheet' href='../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css'>
	<link rel='stylesheet' href='../bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css'>
	<script src='../bower_components/jquery/dist/jquery.js'></script>
	<link rel='stylesheet' href='../plugins/iCheck/flat/blue.css'>
	<script type='text/javascript'>
		//script preloader
		(function( $ ) {   
			$(window).on('load', function(){
				$('#loader-wrapper').fadeOut('slow',function(){
					$(this).hide();
				});
			});
		})(jQuery);
		//slow bisa diganti dengan angka misal 2000 
	</script>
	
	<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js'></script> 
	<script type='text/javascript'> 
		$(document).ready(function() { 
		// ketika checkbox dengan id semua diklik,  
		// maka semua checkbox akan tercentang. 
			$('#semua').click(function(){ 
				$(this).parents('#centang:eq(0)').
				find(':checkbox').attr('checked', this.checked); 
			});
		});   
	</script>
<!-- -->

<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src='http://html5shim.googlecode.com/svn/trunk/html5.js'></script>
    <![endif]-->
</head>
<body>
<div class='navbar navbar-fixed-top'>
	<div class='navbar-inner'>
		<div class='container'>
			<a class='brand' href='#'>Admin Polling </a>
			<ul class='nav pull-right'>
				<li class='dropdown'><a href='#'' class='dropdown-toggle' data-toggle='dropdown'> <h5>Selamat datang $me di HALAMAN ADMIN </h5></a></li>
			</ul>
		</div>
	</div>
</div>
<!-- /navbar -->
<div class='subnavbar'>
	<div class='subnavbar-inner'>
		<div class='container'>
			<ul class='mainnav'>
				<li><a href='?pg='><i class='icon-dashboard'></i><span>Dashboard</span></a></li>
				<li><a href='?pg=user' class='shortcut'><i class='shortcut-icon icon-user'></i><span class='shortcut-label'>Users</span></a></li>
				<li><a href='?pg=pilihan' class='shortcut'><i class='shortcut-icon icon-group'></i><span class='shortcut-label'>Calon</span></a></li>
				<li><a href='?pg=setting'><i class='icon-wrench'></i><span>Setting</span></a></li>
				<li><a href='logout.php'><i class='icon-off'></i><span>Logout</span></a></i>
			</ul>
		</div><!-- /container --> 
	</div> <!-- /subnavbar-inner --> 
</div><!-- /subnavbar -->
<div class='main'>
<div id='loader-wrapper'>	
	<div id='loader'></div>
</div>
	<div class='main-inner'>
		<div class='container'>
			<div class='row'>";
			if($pg=='') {
				echo"
				<div class='row'>
					<div class='span12'>
							<div class='box box-success' align ='center'>
            					<div class='box-header with-border'>
              						<h3 class='box-title'>Progres Hasil Polling</h3>
            					</div><!-- /.box-header -->
            					<div class='box-body'>
									<div class='table-responsive'>
										<table id='example2' class='table table-striped table-striped with-border'>
                							<thead>
												<tr>
                  									<td>#</td>
													<td align='center'>Ketua</td>
                  									<td  align='center'>Wakil</td>
                  									<td width='400px'  align='center'>Progress</td>
													<td width='50px'  align='center'>Persentase</td>
													<td width='50px'  align='center'>Jumlah</td>
                								</tr>
											</thead>";
											$calonQ= mysql_query("select*from pilihan");
											$no=0;
											while($calon = mysql_fetch_array($calonQ)) {
												$no++;
												echo"
												<tr>
													<td align='center'>$no</td>";
													$ketua = mysql_fetch_array(mysql_query("select*from tb_user where nik = $calon[ketua]"));
													echo"
                  									<td>$ketua[nama]</td>";
													$wakil = mysql_fetch_array(mysql_query("select*from tb_user where nik = $calon[wakil]"));
													echo"
                  									<td>$wakil[nama]</td>";
													$data = mysql_num_rows(mysql_query("select * from tb_user"));
													$nilaiQ = mysql_query("select * from tb_hasil where id_pilihan = '$calon[id]'");
													$row = mysql_num_rows($nilaiQ);
													if(empty($row)) { 
														$row=0; 
													}
													$percen = ($row/$data)*100;
													echo"
                 									<td align = 'center'>
														<div class='progress progress-striped active'>
															<div class='bar' style='width: $row%'></div>
														</div>
													</td>
                  									<td align = 'center'><span class='badge bg-green'>$percen</span></td>
													<td align = 'center'><span class='badge bg-green'>$row</span></td>";
													echo"
												</tr>";
											}
												$jml = mysql_num_rows(mysql_query("select*from tb_hasil"));
												$jmlp = mysql_num_rows(mysql_query("select*from tb_user"));
												echo"
												<tr>
													<td colspan='2'>Jumlah Participant : $jml</td>
													<td colspan='1'></td>
													<td colspan='2'>Jumlah Total Pemilih : $jmlp</td>
													<td colspan='1'></td>
												</tr>
              							</table>
									</div>
            					</div> <!-- /.box-body -->
          					</div>
					</div>
				</div>
				";
			}elseif($pg=='user'){
				if($ac=='reset'){
					$id=$_GET['id'];
					$resets=mysql_query("update tb_user set status=0 where id='$id'");
					?><script language="javascript"> alert('Data telah di reset !'); document.location='?pg=user';</script><?php
				}
				if($ac=='resetall'){
					$resetQ=mysql_query("select*from tb_user where status = 1");
					while($reset = mysql_fetch_array($resetQ)){
						$set=mysql_query("update tb_user set status=0 where id='$reset[id]'");
					}
					?><script language="javascript"> alert('Data telah di reset !'); document.location='?pg=user';</script><?php
				}
				echo"
					<div class='box box-success'>
						<div class='box-header with-border'>
							<h3 class='box-title'>Data Pemilih</h3>
                            <div class='box-tools btn-group'>
								<a href='?pg=importuser' class='btn btn-sm btn-success'><i class='fa fa-sign-in'></i> Import</a>
								<a href='?pg=$pg&ac=resetall' class='btn btn-sm btn-success'><i class='fa fa-refresh'></i> Reset All</a>
								<a href='?pg=cekpil' class='btn btn-sm btn-success'><i class='fa fa-sign-in'></i> Cek Semua Pilihan</a>
							</div>
						</div><!-- /.box-header -->
						<div class='box-body'>
							<div class='table-responsive'>
								<table id='example1' class='table table-striped'>
									<thead>
										<tr>	
											<th width='5px'>#</th>
											<th>NIK</th>
											<th>Nama</th>
											<th>Status</th>
											<th>action</th>
										</tr>
									</thead>
									<tbody>";
									$siswaQ = mysql_query("SELECT * FROM tb_user");
									$no=0;
									while($siswa = mysql_fetch_array($siswaQ)) {
										$no++;
										echo "
										<tr>
											<td> $no </td>
											<td>$siswa[nik]</td>
											<td>$siswa[nama]</td>";
											if($siswa['status']!=0){
												$ket = "<span class='label label-success'>Sudah Memilih</span>";
											}else{
												$ket = "<span class='label label-danger'>Belum Memilih</span>";
											}
											echo"
											<td>$ket</td>
											<td><a href='?pg=$pg&ac=reset&id=$siswa[id]' class='btn btn-warning'><i class='fa fa-refresh'></i> Reset</a></td>
										</tr>";
									}
									echo "
									</tbody>
								</table>
							</div>
						</div><!-- /.box-body -->
					</div><!-- /.box -->
				";
			}elseif($pg=='cekpil'){
				echo"
					<div class='box box-success'>
						<div class='box-header with-border'>
							<h3 class='box-title'>Data Pemilih</h3>
                            <div class='box-tools btn-group'>
								<a href='?pg=user' class='btn btn-sm btn-success'><i class='fa fa-mail-reply'></i> Back</a>
							</div>
						</div><!-- /.box-header -->
						<div class='box-body'>
							<div class='table-responsive'>
								<table id='example1' class='table table-striped'>
									<thead>
										<tr>	
											<th width='5px'>#</th>
											<th>NIK</th>
											<th>Nama</th>
											<th>Pilihan</th>
										</tr>
									</thead>
									<tbody>";
									$siswaQ = mysql_query("SELECT * FROM tb_user");
									$no=0;
									while($siswa = mysql_fetch_array($siswaQ)) {
										$no++;
										echo "
										<tr>
											<td> $no </td>
											<td>$siswa[nik]</td>
											<td>$siswa[nama]</td>";
											$pil=mysql_fetch_array(mysql_query("select*from tb_hasil where nik_user='$siswa[id]'"));
											$calon=mysql_fetch_array(mysql_query("select*from pilihan where id='$pil[id]'"));
											$ketua=mysql_fetch_array(mysql_query("select*from tb_user where nik='$calon[ketua]'"));
											$wakil=mysql_fetch_array(mysql_query("select*from tb_user where nik='$calon[wakil]'"));
											$pilihan = "$ketua[nama] Dan $wakil[nama]";
											echo"
											<td> $pilihan</td>
										</tr>";
									}
									echo "
									</tbody>
								</table>
							</div>
						</div><!-- /.box-body -->
					</div><!-- /.box -->
				";
			}elseif($pg=='importuser'){
				if(isset($_POST['submit'])){
                    $file = $_FILES['file']['name'];
                    $temp = $_FILES['file']['tmp_name'];
					$ext = explode('.',$file);
					$ext = end($ext);
					if($ext<>'xls') {
						$info = info('Gunakan file Ms. Excel 93-2007 Workbook (.xls)','NO');
                    } else {
						$data = new Spreadsheet_Excel_Reader($temp);
						$hasildata = $data->rowcount($sheet_index=0);
						$sukses = $gagal = 0;
						for ($i=2; $i<=$hasildata; $i++) {
							$nik = $data->val($i,1);
							$nama = $data->val($i,2);
							$status = 0;
                            
							$exec = mysql_query("INSERT INTO tb_user (nik, nama, status) VALUES ('$nik','$nama','$status')");
							
                         }
						 ?><script language="javascript"> alert('Berhasil Upload, Silahkan cek data'); document.location='?pg=user';</script><?php
					}
                }
				echo"
					<div class='row'>
						<div class='col-md-3'></div>
						<div class='col-md-6'>
							<form action='' method='post' enctype='multipart/form-data'>
								<div class='box box-primary'>
									<div class='box-header with-border'>
                                        <h3 class='box-title'>Import User</h3>
                                        <div class='box-tools pull-right btn-group'>
                                            <button type='submit' name='submit' class='btn btn-sm btn-primary'><i class='fa fa-check'></i> Import</button>
                                        </div>
                                    </div><!-- /.box-header -->
									<div class='box-body'>
										<div class='form-group'>
											<label>Pilih File</label>
											<input type='file' name='file' class='form-control' required='true'/>
										</div>
										<p>Sebelum meng-import pastikan file yang akan anda import sudah dalam bentuk Ms. Excel 97-2003 Workbook (.xls) dan format penulisan harus sesuai dengan yang telah ditentukan. <br/>
										</p>
									</div><!-- /.box-body -->
									<div class='box-footer'>
										<a href='importuser.xls'><i class='fa fa-file-excel-o'></i> Download Format</a>
									</div>
								</div><!-- /.box -->
                            </form>
                        </div>
                    </div>
				";
			}elseif($pg=='pilihan'){
				echo"
				<div class='row'>
					<div class='span8'>
						<div class='box box-success'>
							<div class='box-header with-border'>
								<h3 class='box-title'>Data Calon</h3>
							</div><!-- /.box-header -->
							<div class='box-body'>
								<div class='table-responsive'>
									<table id='example1' class='table table-striped'>
										<thead>
											<tr>
												<th width='5px'>#</th>
												<th>Ketua</th>
												<th>Wakil</th>
												<th width='5px'>Action</th>
											</tr>
										</thead>
										<tbody>";
										$siswaQ = mysql_query("SELECT * FROM pilihan");
										$no=0;
										while($siswa = mysql_fetch_array($siswaQ)) {
											$no++;
											echo "
											<tr>
												<td>$no</td>";
												$ketua = mysql_fetch_array(mysql_query("select*from tb_user where nik = '$siswa[ketua]'"));
												$wakil = mysql_fetch_array(mysql_query("select*from tb_user where nik = '$siswa[wakil]'"));
												echo"
												<td>$ketua[nama]</td>
												<td>$wakil[nama]</td>
												<td align='center'>
													<div class='btn-group'>
														<button type='button' class='btn btn-xs btn-default dropdown-toggle' data-toggle='dropdown'>
															<span class='caret'></span>
															<span class='sr-only'>Toggle Dropdown</span>
														</button>
														<ul class='dropdown-menu' role='menu'>
															<li><a href='?pg=$pg&ac=edit&id=$siswa[id]'>Edit</a></li>
															<li><a href='?pg=$pg&ac=hapus&id=$siswa[id]'>Hapus</a></li>
														</ul>
													</div>
												</td>
											</tr>";
										}
										echo "
										</tbody>
									</table>
								</div>
							</div><!-- /.box-body -->
						</div><!-- /.box -->
					</div>";
					if($ac==''){
						if(isset($_POST['submit'])){
							$ketua = $_POST['ketua'];
							$wakil = $_POST['wakil'];
							
							$cek1 = mysql_fetch_array(mysql_query("select*from tb_user where nik='$ketua'"));
							$cek2 = mysql_fetch_array(mysql_query("select*from tb_user where nik='$wakil'"));
							if($cek1 !=0 AND $cek2 !=0){
								$insert=mysql_query("insert into pilihan (ketua,wakil) value ('$ketua','$wakil')")or die (mysql_error());
								
								if($insert !=0){
									?><script language="javascript"> alert('Berhasil Input !'); document.location='?pg=pilihan';</script><?php
								}else{
									?><script language="javascript"> alert('Gagal Input !'); document.location='?pg=pilihan';</script><?php
								}
							}else{
								?><script language="javascript"> alert('NIK Ketua atau Wakil salah !'); document.location='?pg=pilihan';</script><?php
							}
						}
					echo"
					<div class='span4'>
						<form action='' method='post'>
							<div class='box box-success'>
								<div class='box-header with-border'>
									<h3 class='box-title'>Tambah</h3>
									<div class='box-tools pull-right btn-group'>
										<button type='submit' name='submit' class='btn btn-sm btn-primary'><i class='fa fa-check'></i> Simpan</button>
									</div>
								</div><!-- /.box-header -->
								<div class='box-body'>
									<div class='form-group'>
										<label>NIK Calon Ketua</label>
										<input type='text' name='ketua' class='form-control' required='true'/>
									</div>
									<div class='form-group'>
										<label>NIK Calon Wakil</label>
										<input type='text' name='wakil' class='form-control' required='true'/>
									</div>
								</div><!-- /.box-body -->
							</div><!-- /.box -->
						</form>
					</div>";
					}elseif($ac=='edit'){
						$idpil = $_GET['id'];
						$pil = mysql_fetch_array(mysql_query("select*from pilihan where id='$idpil'"));
						if(isset($_POST['submit'])){
							$ketua = $_POST['ketua'];
							$wakil = $_POST['wakil'];
							
							$cek1 = mysql_fetch_array(mysql_query("select*from tb_user where nik='$ketua'"));
							$cek2 = mysql_fetch_array(mysql_query("select*from tb_user where nik='$wakil'"));
							if($cek1 !=0 AND $cek2 !=0){
								$update=mysql_query("update pilihan set ketua = '$ketua' , wakil='$wakil' where id = '$idpil' ");
								
								if($update !=0){
									?><script language="javascript"> alert('Berhasil Update !'); document.location='?pg=pilihan';</script><?php
								}else{
									?><script language="javascript"> alert('Gagal Update !'); document.location='?pg=pilihan';</script><?php
								}
							}else{
								?><script language="javascript"> alert('NIK yang anda Update Tidak Terdaftar di table pemilih !'); document.location='?pg=pilihan';</script><?php
							}
						}
					echo"
					<div class='span4'>
						<form action='' method='post'>
							<div class='box box-success'>
								<div class='box-header with-border'>
									<h3 class='box-title'>Tambah</h3>
									<div class='box-tools pull-right btn-group'>
										<button type='submit' name='submit' class='btn btn-sm btn-primary'><i class='fa fa-check'></i> Simpan</button>
									</div>
								</div><!-- /.box-header -->
								<div class='box-body'>
									<div class='form-group'>
										<label>NIK Calon Ketua</label>
										<input type='text' name='ketua' value='$pil[ketua]' class='form-control' required='true'/>
									</div>
									<div class='form-group'>
										<label>NIK Calon Wakil</label>
										<input type='text' name='wakil' value='$pil[wakil]' class='form-control' required='true'/>
									</div>
								</div><!-- /.box-body -->
							</div><!-- /.box -->
						</form>
					</div>";
					}elseif($ac=='hapus'){
						$idpil = $_GET['id'];
						$del = mysql_query("delete from pilihan where id = '$idpil' ");
						if($del !=0 ){
							?><script language="javascript"> alert('Berhasil Menghapus Calon !'); document.location='?pg=pilihan';</script><?php
						}else{
							?><script language="javascript"> alert('Gagal Menghapus Calon !'); document.location='?pg=pilihan';</script><?php
						}
					}
					echo"
				</div>	
				";
			}elseif($pg=='setting'){
				if(isset($_POST['submit'])) {
                    if(!empty($_POST['data'])) {
                        $data = $_POST['data'];
                        if($data<>'') {
                            foreach($data as $table) {
                                if($table<>'pengawas') {
                                    mysql_query("TRUNCATE $table");
                                } else {
                                    mysql_query("DELETE FROM $table WHERE level!='admin'");
                                }
                            }
                        }
                    }
				}
				echo"
				<div class='col-md-6'>	
					<form action='' method='post'>
						<div class='box box-danger'>
							<div class='box-header with-border'>
								<h3 class='box-title'>Kosongkan Data</h3>
								<div class='box-tools pull-right btn-group'>
									<button type='submit' name='submit' class='btn btn-sm btn-danger'><i class='fa fa-trash-o'></i> Kosongkan</button>
								</div>
							</div><!-- /.box-header -->
							<div class='box-body'>
								<div class='form-group'>
									<label>Pilih Data</label><br/>
									<div class='col-md-10'>
										<div class='checkbox'>
											<label><input type='checkbox' name='data[]' value='tb_user'/> Data Pemilih</label><br/>
											<label><input type='checkbox' name='data[]' value='pilihan'/> Data Calon</label><br/>
											<label><input type='checkbox' name='data[]' value='tb_hasil'/> Data Polling</label><br/>
										</div>
									</div>
									<div class='col-md-7'>
										<p class='text-danger'><i class='fa fa-warning'></i> <strong>Mohon di ingat!</strong> Data yang telah dikosongkan tidak dapat dikembalikan.</p>
									</div>
								</div>
                            </div><!-- /.box-body -->
						</div><!-- /.box -->
					</form>
				</div>
				";
			}else{
				echo"
				<div class='span12'>
					<div class='error-container'>
						<h1>404</h1>
						<h2>Who! bad trip man. No more pixesl for you.</h2>
					</div> <!-- /error-container -->
				</div> <!-- /span12 -->
				";
			}
			echo"
			</div><!-- /row --> 
		</div><!-- /container --> 
	</div><!-- /extra-inner --> 
</div>
<!-- Le javascript ================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src='../js/jquery-1.7.2.min.js'></script> 
<script src='../js/excanvas.min.js'></script> 
<script src='../js/chart.min.js' type='text/javascript'></script> 
<script src='../js/bootstrap.js'></script>
<script language='javascript' type='text/javascript' src='../js/full-calendar/fullcalendar.min.js'></script>
 
<script src='../js/base.js'></script> 
	<script>

		var pieData = [
				{
				    value: 30,
				    color: '#F38630'
				},
				{
				    value: 50,
				    color: '#E0E4CC'
				},
				{
				    value: 100,
				    color: '#69D2E7'
				}

		];

		var myPie = new Chart(document.getElementById('pie-chart').getContext('2d')).Pie(pieData);

		var barChartData = {
			labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
			datasets: [
				{
				    fillColor: 'rgba(220,220,220,0.5)',
				    strokeColor: 'rgba(220,220,220,1)',
				    data: [65, 59, 90, 81, 56, 55, 40]
				},
				{
				    fillColor: 'rgba(151,187,205,0.5)',
				    strokeColor: 'rgba(151,187,205,1)',
				    data: [28, 48, 40, 19, 96, 27, 100]
				}
			]

		}

		var myLine = new Chart(document.getElementById('bar-chart').getContext('2d')).Bar(barChartData);
		var myLine = new Chart(document.getElementById('bar-chart1').getContext('2d')).Bar(barChartData);
		var myLine = new Chart(document.getElementById('bar-chart2').getContext('2d')).Bar(barChartData);
		var myLine = new Chart(document.getElementById('bar-chart3').getContext('2d')).Bar(barChartData);
	
	</script>
<!-- /Calendar -->
	
<!-- JS From AdminLTE -->
	<script src='../bower_components/jquery/dist/jquery.min.js'></script>
	<script src='../bower_components/bootstrap/dist/js/bootstrap.min.js'></script>
	<script src='../bower_components/datatables.net/js/jquery.dataTables.min.js'></script>
	<script src='../bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js'></script>
	<script src='../bower_components/jquery-slimscroll/jquery.slimscroll.min.js'></script>
	<script src='../bower_components/chart.js/Chart.js'></script>
	<script src='../bower_components/fastclick/lib/fastclick.js'></script>
	<script src='../dist/js/adminlte.min.js'></script>
	<script src='../dist/js/demo.js'></script>
	<script src='../bower_components/ckeditor/ckeditor.js'></script>
	<script src='../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js'></script>
	<script src='../plugins/iCheck/icheck.min.js'></script>


	<script>
  		$(function () {
    		CKEDITOR.replace('editor1')
   		    $('.textarea').wysihtml5()
  		});
		$('#example1').DataTable();
							
		function printkartu(idkelas) {
			$('#loadframe').attr('src','kartu.php?id_kelas='+idkelas);
		}
	</script>
	
</body>
</html>";
}else{
	echo"<script>alert('Anda belum login! Silahkan login terlebih dahulu!');window.location='../';</script>"; 
}
?>
