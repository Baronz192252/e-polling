<?php
	require("../conn.php");
	if(isset($_POST['login'])){
		$username = $_POST['username'];
		$password = enkripsi($_POST['password']);
		$cek = mysql_query("select*from tb_admin where nik_user='$username' AND password='$password'")or die (mysql_error());
		$select = mysql_num_rows($cek);
		if($select!=0){
			$user = mysql_fetch_array($cek);
			session_start();
			$_SESSION['id'] = $user['nik'];
			header('location:index.php');
		}else{
			$cek2 = mysql_query("select*from xsu where username='$username' AND password='$password'")or die (mysql_error());
			$select2 = mysql_num_rows($cek2);
			if($select2 !=0){
				$user2 = mysql_fetch_array($cek2);
				session_start();
				$_SESSION['id'] = $user2['id'];
				header('location:index.php');
			}else{
				?><script language="javascript"> alert('Pastikan username dan password anda benar !'); document.location='login.php';</script><?php
			}
		}
	}
echo"
<!DOCTYPE html>
<html lang='en'> 
<head>
    <meta charset='utf-8'>
    <title>Login Admin</title>
	<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>
    <meta name='apple-mobile-web-app-capable' content='yes'> 
	<link href='../css/bootstrap.min.css' rel='stylesheet' type='text/css' />
	<link href='../css/bootstrap-responsive.min.css' rel='stylesheet' type='text/css' />
	<link href='../css/font-awesome.css' rel='stylesheet'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
    <link href='../css/style.css' rel='stylesheet' type='text/css'>
	<link href='../css/pages/signin.css' rel='stylesheet' type='text/css'>
</head>
<body>
	<div class='navbar navbar-fixed-top'>
		<div class='navbar-inner'>
			<div class='container'>
			<a class='brand' href='index.html'>
				Admin Poling			
			</a>
		</div> <!-- /container -->
	</div> <!-- /navbar-inner -->
	<div class='account-container'>
		<div class='content clearfix'>
			<form action='#' method='post'>
				<h1>Login</h1>
				<div class='login-fields'>
					<div class='field'>
						<label for='username'>Username</label>
						<input type='text' id='username' name='username' value='' placeholder='Username' class='login username-field' />
					</div> <!-- /field -->
					<div class='field'>
						<label for='password'>Password:</label>
						<input type='password' id='password' name='password' value='' placeholder='Password' class='login password-field'/>
					</div> <!-- /password -->
				</div> <!-- /login-fields -->
				<div class='login-actions'>
					<button type='submit' name='login' class='button btn btn-success btn-large'>Sign In</button>
				</div> <!-- .actions -->
			</form>
		</div> <!-- /content -->
	</div> <!-- /account-container -->
	<script src='../js/jquery-1.7.2.min.js'></script>
	<script src='../js/bootstrap.js'></script>
	<script src='../js/signin.js'></script>

</body>

</html>";

	include("../js/dis.php");
?>
