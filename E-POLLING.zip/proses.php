<?php
 require("conn.php");
 $nik_user = $_GET['nik_user'];
 $idpil = $_GET['idpil'];
 
 $insert = mysql_query("insert into tb_hasil (nik_user, id_pilihan) value ('$nik_user','$idpil')")or die (mysql_error());
 
 $user = mysql_query("update tb_user set status = 1 where nik='$nik_user'")or die (mysql_error());
 
 if($insert !=0 AND $user !=0){
	 ?><script language="javascript"> alert('Terima Kasih atas Partisipasi anda...'); document.location='logout.php';</script><?php
 }else{
	 ?><script language="javascript"> alert('Gagal Memilih !'); document.location='poling.php';</script><?php
 }

?>