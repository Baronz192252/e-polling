<?php
require("conn.php");
if(isset($_POST['submit'])){
	$nik = $_POST['password'];
	$cek = mysql_query("select*from tb_user where nik='$nik'")or die (mysql_error());
	$select = mysql_num_rows($cek);
	if($select<=0){
		?><script language="javascript"> alert('Pastikan NIK Anda Sudah Benar !'); document.location='index.php';</script><?php 
	}else{
		$user = mysql_fetch_array($cek);
		if($user['status'] != 0){
			?><script language="javascript"> alert('Anda Sudah Memilih !'); document.location='index.php';</script><?php
		}else{
			session_start();
			$_SESSION['id'] = $user['nik'];
			header('location:poling.php');
		}
	}
}
echo"
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='utf-8'>
    <title>Login E-Polling</title>
	<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>
    <meta name='apple-mobile-web-app-capable' content='yes'> 
	<link href='css/bootstrap.min.css' rel='stylesheet'>
	<link href='css/bootstrap-responsive.min.css' rel='stylesheet'>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'
        rel='stylesheet'>
	<link href='css/font-awesome.css' rel='stylesheet'>
	<link href='css/style.css' rel='stylesheet'>
	<link href='css/pages/signin.css' rel='stylesheet' type='text/css'>
	<link href='css/pages/reports.css' rel='stylesheet'>
	
	<link rel='stylesheet' href='plugins/font-awesome-4.4.0/css/font-awesome.min.css'/>
<!--	<link rel='stylesheet' href='bower_components/bootstrap/dist/css/bootstrap.min.css'> -->
	<link rel='stylesheet' href='dist/css/AdminLTE.min.css'/>
	<link rel='stylesheet' href='dist/css/preloader.css'/>
	<link rel='stylesheet' href='dist/css/skins/skin-green.min.css'/>
	<link rel='stylesheet' href='dist/css/skins/skin-green-light.min.css'/>
	<link rel='stylesheet' href='plugins/datatables/dataTables.bootstrap.css'/>
	<link rel='stylesheet' href='bower_components/font-awesome/css/font-awesome.min.css'>
	<link rel='stylesheet' href='bower_components/Ionicons/css/ionicons.min.css'>
	<link rel='stylesheet' href='dist/css/skins/_all-skins.css'>
	<link rel='stylesheet' href='dist/css/skins/_all-skins.min.css'>
	<link rel='stylesheet' href='bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css'>
	<link rel='stylesheet' href='bower_components/bootstrap-daterangepicker/daterangepicker.css'>
	<link rel='stylesheet' href='plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css'>
	<link rel='stylesheet' href='bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css'>
	<script src='bower_components/jquery/dist/jquery.js'></script>
	<script type='text/javascript'>
		//script preloader
		(function( $ ) {   
			$(window).on('load', function(){
				$('#loader-wrapper').fadeOut('slow',function(){
					$(this).hide();
				});
			});
		})(jQuery);
		//slow bisa diganti dengan angka misal 2000 
	</script>
	
	
</head>

<body>
<div class='main'>
	<div id='loader-wrapper'>	
		<div id='loader'></div>
	</div>
	<div class='main-inner'>
		<div class='container'>
	
			<div class='navbar navbar-fixed-top'>
				<div class='navbar-inner'>
					<div class='container'>
						
					</div> <!-- /container -->
				</div> <!-- /navbar-inner -->
			</div> <!-- /navbar -->
			
			<div class='account-container'>
				<div class='content clearfix'>
					<form action='' method='post'>
					<h3 align='center'>RealCount </br> Pemilihan Ketua dan Sekretaris </br></h3></br>
						<div class='login-fields'>
							<div class='field'>
								<label for='password'>NIK</label>
								<input type='password' name='password' class='login password-field'/>
							</div> <!-- /password -->
						</div> <!-- /login-fields -->
						<div class='login-actions'>
							<button type='submit' name='submit' class='button btn btn-success btn-large'>Login</button>
						</div> <!-- .actions -->
					</form>
				</div> <!-- /content -->
			</div> <!-- /account-container -->
			
			</br>
			</br>
			</br>
			<div class='row'>
				<div class='span12'>
					<div class='box box-success' align ='center'>
            			<div class='box-header with-border'>
              				<h3 class='box-title'>Progres Hasil RealCount</h3>
            			</div><!-- /.box-header -->
            			<div class='box-body'>
							<div class='table-responsive'>
								<table id='example2' class='table table-striped table-striped with-border'>
                					<thead>
										<tr>
                							<td>#</td>
											<td align='center'>Ketua</td>
                							<td  align='center'>Sekretaris</td>
                							<td width='400px'  align='center'>Progress</td>
											<td width='50px'  align='center'>Persentase</td>
											<td width='50px'  align='center'>Jumlah</td>
                						</tr>
									</thead>";
									$calonQ= mysql_query("select*from pilihan");
									$no=0;
									while($calon = mysql_fetch_array($calonQ)) {
										$no++;
										echo"
										<tr>
											<td align='center'>$no</td>";
											$ketua = mysql_fetch_array(mysql_query("select*from tb_user where nik = $calon[ketua]"));
											echo"
                  							<td>$ketua[nama]</td>";
											$Sekretaris = mysql_fetch_array(mysql_query("select*from tb_user where nik = $calon[wakil]"));
											echo"
                  							<td>$Sekretaris[nama]</td>";
											$data = mysql_num_rows(mysql_query("select * from tb_user"));
											$nilaiQ = mysql_query("select * from tb_hasil where id_pilihan = '$calon[id]'");
											$row = mysql_num_rows($nilaiQ);
											if(empty($row)) { 
												$row=0; 
											}
											$percen = ($row/$data)*100;
											echo"
                 							<td align = 'center'>
												<div class='progress progress-striped active'>
													<div class='bar' style='width: $row%'></div>
												</div>
											</td>
                  							<td align = 'center'><span class='badge bg-green'>$percen</span></td>
											<td align = 'center'><span class='badge bg-green'>$row</span></td>";
											echo"
										</tr>";
									}
									$jml = mysql_num_rows(mysql_query("select*from tb_hasil"));
									$jmlp = mysql_num_rows(mysql_query("select*from tb_user"));
									echo"
										<tr>
											<td colspan='2'>Jumlah Participant : $jml</td>
											<td colspan='1'></td>
											<td colspan='2'>Jumlah Total Pemilih : $jmlp</td>
											<td colspan='1'></td>
										</tr>
              						</table>
								</div>
            				</div> <!-- /.box-body -->
          				</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>	
	<script src='js/jquery-1.7.2.min.js'></script>
	<script src='js/bootstrap.js'></script>
	<script src='js/signin.js'></script>
	<script src='js/jquery-1.7.2.min.js'></script>
	
<script src='js/excanvas.min.js'></script> 
<script src='js/chart.min.js' type='text/javascript'></script> 
<script src='js/bootstrap.js'></script>
<script language='javascript' type='text/javascript' src='js/full-calendar/fullcalendar.min.js'></script>
 
<script src='js/base.js'></script> 
	<script>

		var pieData = [
				{
				    value: 30,
				    color: '#F38630'
				},
				{
				    value: 50,
				    color: '#E0E4CC'
				},
				{
				    value: 100,
				    color: '#69D2E7'
				}

		];

		var myPie = new Chart(document.getElementById('pie-chart').getContext('2d')).Pie(pieData);

		var barChartData = {
			labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
			datasets: [
				{
				    fillColor: 'rgba(220,220,220,0.5)',
				    strokeColor: 'rgba(220,220,220,1)',
				    data: [65, 59, 90, 81, 56, 55, 40]
				},
				{
				    fillColor: 'rgba(151,187,205,0.5)',
				    strokeColor: 'rgba(151,187,205,1)',
				    data: [28, 48, 40, 19, 96, 27, 100]
				}
			]

		}

		var myLine = new Chart(document.getElementById('bar-chart').getContext('2d')).Bar(barChartData);
		var myLine = new Chart(document.getElementById('bar-chart1').getContext('2d')).Bar(barChartData);
		var myLine = new Chart(document.getElementById('bar-chart2').getContext('2d')).Bar(barChartData);
		var myLine = new Chart(document.getElementById('bar-chart3').getContext('2d')).Bar(barChartData);
	
	</script>
<!-- /Calendar -->
	
<!-- JS From AdminLTE -->
	<script src='bower_components/jquery/dist/jquery.min.js'></script>
	<script src='bower_components/bootstrap/dist/js/bootstrap.min.js'></script>
	<script src='bower_components/datatables.net/js/jquery.dataTables.min.js'></script>
	<script src='bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js'></script>
	<script src='bower_components/jquery-slimscroll/jquery.slimscroll.min.js'></script>
	<script src='bower_components/chart.js/Chart.js'></script>
	<script src='bower_components/fastclick/lib/fastclick.js'></script>
	<script src='dist/js/adminlte.min.js'></script>
	<script src='dist/js/demo.js'></script>
	<script src='bower_components/ckeditor/ckeditor.js'></script>
	<script src='plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js'></script>


	<script>
  					$(function () {
    				CKEDITOR.replace('editor1')
   					 $('.textarea').wysihtml5()
  					});
					$('#example1').DataTable();
					
					
					function printkartu(idkelas) {
						$('#loadframe').attr('src','kartu.php?id_kelas='+idkelas);
					}
				</script>		
</body>

</html>";
include("js/dis.php");
?>